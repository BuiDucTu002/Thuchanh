package huce.fit.pbank;

public class Searching {
    public void searchByName(){
        //code here
    }
}
