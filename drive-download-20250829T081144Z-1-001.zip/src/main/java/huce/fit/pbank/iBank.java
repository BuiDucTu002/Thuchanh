package huce.fit.pbank;

public interface iBank {
    void connectToBank();
    void transferToBank();
}
